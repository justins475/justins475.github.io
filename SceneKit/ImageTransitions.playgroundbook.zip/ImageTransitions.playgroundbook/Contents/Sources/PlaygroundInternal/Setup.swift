import PlaygroundSupport
import UIKit
import simd

public class ImageTransitionViewController: UIViewController {
    lazy var filterView: UIImageView = {
        let filterView = UIImageView()
        return filterView
    }()
    
    var shouldAnimate = true
    
    let context = CIContext(options: nil)
    var progress = 0.0
    var increment = 0.0
    var displayLink: CADisplayLink? = nil
    
    var firstImage: UIImage? = nil
    var secondImage: UIImage? = nil
    var filterName: String? = "CIDissolveTransition"
    var incomingProgress: Double = 0
    
    public override func viewDidLoad() {
        super.viewDidLoad()
        self.view.addSubview(filterView)
    }
    
    public override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        filterView.bounds = CGRect(x: 0, y: 0, width: 500, height: 500)
        filterView.center = CGPoint(x: view.bounds.midX, y: view.bounds.midY)
    }
    
    public func setImage() {
        guard firstImage != nil, secondImage != nil, filterName != nil else {
            return
        }
        guard shouldAnimate == true else {
            NSLog("gek process is \(incomingProgress)")
            let partiallyDissolvedCIImage = dissolveFilter(CIImage(image: firstImage!)!, to: CIImage(image: secondImage!)!, time: incomingProgress)
            showCIImage(partiallyDissolvedCIImage!, in: filterView, context: context)
            return
            
        }
        beginTransition()
    }
    
    func beginTransition() {
        progress = 0
        increment = 0.008
        displayLink = CADisplayLink(target: self, selector: #selector(stepTime))
        displayLink?.add(to: RunLoop.main, forMode: RunLoopMode.defaultRunLoopMode)
    }
    
    @objc func stepTime() {
        progress += increment

        if progress > 1 {
            displayLink?.invalidate()
        } else {
            guard let dissolvedCIImage = dissolveFilter(CIImage(image: firstImage!)!, to: CIImage(image: secondImage!)!, time: progress) else {
                return
            }
            showCIImage(dissolvedCIImage, in: filterView, context: context)
        }
    }
    
    func dissolveFilter(_ inputImage: CIImage,
                        to targetImage: CIImage,
                        time: TimeInterval) -> CIImage? {
        let filter = CIFilter(name: filterName!)!
        filter.setValue(CIImage(image: firstImage!), forKey: kCIInputImageKey)
        filter.setValue(CIImage(image: secondImage!), forKey: kCIInputTargetImageKey)
        filter.setValue(time, forKey: kCIInputTimeKey)
        return filter.outputImage
    }
    
    
    func showCIImage(_ ciImage: CIImage,
                     in imageView: UIImageView,
                     context: CIContext) {
        NSLog("gek in showCIImage")
        guard let cgImage = context.createCGImage(ciImage, from: ciImage.extent) else {
            NSLog("gek returning")
            return
        }
        let uiImage = UIImage(cgImage: cgImage)
        filterView.image = uiImage
    }
}

extension ImageTransitionViewController: PlaygroundLiveViewMessageHandler {
    public func liveViewMessageConnectionOpened() {
        // We don't need to do anything in particular when the connection opens.
    }
    
    public func liveViewMessageConnectionClosed() {
        // We don't need to do anything in particular when the connection closes.
    }
    
    public func receive(_ message: PlaygroundValue) {
        if case .boolean(let shouldAnimate) = message {
            self.shouldAnimate = shouldAnimate
            NSLog("gek shouldan is \(self.shouldAnimate)")
            setImage()
        }
        else if case .string(let string) = message {
            if let img = UIImage(contentsOfFile: string) {
                if firstImage == nil {
                    firstImage = img
                } else {
                    secondImage = img
                }
            } else {
                if let _ = CIFilter(name: string) {
                    filterName = string
                    setImage()
                } else {
                    filterName = "CIDissolveTransition"
                    setImage()
                }
            }
        } else if case .floatingPoint(let progress) = message {
            self.incomingProgress = progress
        }
    }
}
