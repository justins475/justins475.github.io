//#-hidden-code
import UIKit
import PlaygroundSupport
import Foundation

PlaygroundPage.current.needsIndefiniteExecution = true

//#-end-hidden-code
//: The basis of these transition filters is that Core Image will produce a series of CIImages, one at a time, that when animated look like a transition from one image to the next.
//:
//: We have seen the ```inputImage``` and ```targetImage``` set on the previous page. But behind the scenes, in the live view, is where the actual animation happens. We are using a ```CADisplayLink``` to trigger the app to redraw the image over and over while slowly increasing ```process```.
//:
//: Once the two images are set, most transition filters can produce an outputImage, which is a CIImage. This image is a snapshot in time between the beginning and end of the transition. To see what images are produced at each stage in the transition, we need to update the ```kCIInputTimeKey```. This needs to be a value between 0 and 1. See what images you get below when you change the ```process``` variable.

let imageOne: UIImage = <#T##imageOne##UIImage#>
let imageTwo: UIImage = <#T##imageTwo##UIImage#>
let process: Double = <#T##process##Double#>

let filter = CIFilter(name: "CIDissolveTransition")!

filter.setValue(CIImage(image: imageOne), forKey: kCIInputImageKey)
filter.setValue(CIImage(image: imageTwo), forKey: kCIInputTargetImageKey)
filter.setValue(process, forKey: kCIInputTimeKey)

//#-hidden-code
func imageWithImage(image: UIImage, scaledTo: CGSize) -> UIImage {
    UIGraphicsBeginImageContextWithOptions(scaledTo, false, 0.0);
    image.draw(in: CGRect(origin: CGPoint.zero, size: CGSize(width: scaledTo.width, height: scaledTo.height)))
    let scaledImage: UIImage = UIGraphicsGetImageFromCurrentImageContext()!
    UIGraphicsEndImageContext()
    return scaledImage
}
let resizedImageOne = imageWithImage(image: imageOne, scaledTo: CGSize(width: 300, height: 300))
let resizedImageTwo = imageWithImage(image: imageTwo, scaledTo: CGSize(width: 300, height: 300))

let filenameOfImageOne = UUID().uuidString
let filenameOfImageTwo = UUID().uuidString

let dataOne = UIImagePNGRepresentation(resizedImageOne)!
let dataTwo = UIImagePNGRepresentation(resizedImageTwo)!

let paths = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)
let path = paths[0]
let fullPathOne = path.appendingPathComponent(filenameOfImageOne)
let fullPathTwo = path.appendingPathComponent(filenameOfImageTwo)
do {
    try dataOne.write(to: fullPathOne)
    try dataTwo.write(to: fullPathTwo)
} catch {
    NSLog("Couldn't save this image")
}

let page = PlaygroundPage.current
if let proxy = page.liveView as? PlaygroundRemoteLiveViewProxy {
    proxy.send(.floatingPoint(process))
    proxy.send(.string(fullPathOne.path))
    proxy.send(.string(fullPathTwo.path))
    proxy.send(.boolean(false))

} else {
    NSLog("Couldn't send")
}
