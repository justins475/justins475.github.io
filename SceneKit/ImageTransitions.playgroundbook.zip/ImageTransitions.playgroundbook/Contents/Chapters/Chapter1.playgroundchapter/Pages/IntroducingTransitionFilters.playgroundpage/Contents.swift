//#-hidden-code
import UIKit
import PlaygroundSupport
import Foundation

PlaygroundPage.current.needsIndefiniteExecution = true

//#-end-hidden-code
//: This book uses Core Image's Transition category to show some of the transitions between images that you can use. Here's what that'll look like!
let imageOne: UIImage = <#T##imageOne##UIImage#>
let imageTwo: UIImage = <#T##imageTwo##UIImage#>
let filterName = "CIDissolveTransition"

let filter = CIFilter(name: filterName)!

filter.setValue(CIImage(image: imageOne), forKey: kCIInputImageKey)
filter.setValue(CIImage(image: imageTwo), forKey: kCIInputTargetImageKey)

//#-hidden-code
func imageWithImage(image: UIImage, scaledTo: CGSize) -> UIImage {
    UIGraphicsBeginImageContextWithOptions(scaledTo, false, 0.0);
    image.draw(in: CGRect(origin: CGPoint.zero, size: CGSize(width: scaledTo.width, height: scaledTo.height)))
    let scaledImage: UIImage = UIGraphicsGetImageFromCurrentImageContext()!
    UIGraphicsEndImageContext()
    return scaledImage
}
let resizedImageOne = imageWithImage(image: imageOne, scaledTo: CGSize(width: 300, height: 300))
let resizedImageTwo = imageWithImage(image: imageTwo, scaledTo: CGSize(width: 300, height: 300))

let filenameOfImageOne = UUID().uuidString
let filenameOfImageTwo = UUID().uuidString
let dataOne = UIImagePNGRepresentation(resizedImageOne)!
let dataTwo = UIImagePNGRepresentation(resizedImageTwo)!

let paths = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)
let path = paths[0]
let fullPathOne = path.appendingPathComponent(filenameOfImageOne)
let fullPathTwo = path.appendingPathComponent(filenameOfImageTwo)
do {
    try dataOne.write(to: fullPathOne)
    try dataTwo.write(to: fullPathTwo)
} catch {
    NSLog("Couldn't save this image")
}

let page = PlaygroundPage.current
if let proxy = page.liveView as? PlaygroundRemoteLiveViewProxy {
    proxy.send(.string(fullPathOne.path))
    proxy.send(.string(fullPathTwo.path))
    proxy.send(.string(filterName))
    proxy.send(.floatingPoint(0.0))
} else {
    NSLog("Couldn't send")
}
