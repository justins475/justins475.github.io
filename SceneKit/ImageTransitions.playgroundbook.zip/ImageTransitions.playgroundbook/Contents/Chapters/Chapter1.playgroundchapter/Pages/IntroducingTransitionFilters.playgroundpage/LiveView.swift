import PlaygroundSupport
import UIKit

let page = PlaygroundPage.current
page.liveView = ImageTransitionViewController()
