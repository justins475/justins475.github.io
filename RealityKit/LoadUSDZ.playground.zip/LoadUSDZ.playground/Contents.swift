//: A UIKit based Playground for presenting user interface
  
import PlaygroundSupport
import UIKit
import SwiftUI
import RealityKit

struct AR: UIViewRepresentable {
//    @Binding var text: String

    func makeUIView(context: Context) -> ARView {
        let arView = ARView()
        let fileURL = Bundle.main.url(forResource: "teapot", withExtension: "usdz")
        let weelBorrow = try! Entity.load(contentsOf: fileURL!)

        let anchor = AnchorEntity()
        anchor.addChild(weelBorrow)
        anchor.scale = [0.03,0.03,0.01]
        anchor.position.y = -0.5

        arView.scene.anchors.append(anchor)
        
        return arView
    }

    func updateUIView(_ uiView: ARView, context: Context) {
        //uiView.text = text
    }
}

struct ContentView: View {
    @State var modelURL: String
    
    var body: some View {
        ZStack {
            VStack {
                HStack {
                    Text("Model URL")
                        .foregroundColor(Color.black)
                    Spacer()
                    TextField("", text: $modelURL)
                        .foregroundColor(Color.black)
                        .frame(height: 20.0)
                        .textFieldStyle(RoundedBorderTextFieldStyle())

                }
                Spacer()
                AR().foregroundColor(Color.red)
                    .border(Color.black, width: 1)
            }
        }.foregroundColor(Color.white)
    }
}

PlaygroundPage.current.setLiveView(ContentView(modelURL: "asdf"))
